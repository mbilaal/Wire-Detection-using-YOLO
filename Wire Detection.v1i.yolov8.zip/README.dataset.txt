# Wire Detection > 2025-05-17 12:27am
https://universe.roboflow.com/awais-ilfqh/wire-detection-x20l6

Provided by a Roboflow user
License: CC BY 4.0

